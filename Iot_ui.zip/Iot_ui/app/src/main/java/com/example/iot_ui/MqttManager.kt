package com.example.iot_ui

import android.content.Context
import android.util.Log
import info.mqtt.android.service.MqttAndroidClient
import org.eclipse.paho.client.mqttv3.IMqttActionListener
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken
import org.eclipse.paho.client.mqttv3.IMqttToken
import org.eclipse.paho.client.mqttv3.MqttCallback
import org.eclipse.paho.client.mqttv3.MqttConnectOptions
import org.eclipse.paho.client.mqttv3.MqttMessage
import org.json.JSONArray
import org.json.JSONObject

class MqttManager(private val context: Context) {

    private var mqttClient: MqttAndroidClient? = null
    private val tag = "MqttManager"

    // HiveMQ Broker (same as ESP32)
    private val brokerUrl = "tcp://broker.hivemq.com:1883"
    private var currentDeviceId = "esp32_home_001"

    private val telemetryTopic: String
        get() = "iot/$currentDeviceId/telemetry"

    private val controlTopic: String
        get() = "iot/$currentDeviceId/control"

    var onConnectionStatusChanged: ((Boolean, String) -> Unit)? = null
    var onTelemetryReceived: ((TelemetryData) -> Unit)? = null

    // Data Classes
    data class TelemetryData(
        val temperature: Double,
        val humidity: Double,
        val redLed: Int,
        val greenLed: Int,
        val acPower: Boolean,
        val acTargetTemp: Int,
        val fanPower: Boolean,
        val fanSpeed: Int,
        val energyData: EnergyData
    )

    data class EnergyData(
        val acMinutes: Int,
        val fanMinutes: Int,
        val redLedMinutes: Int,
        val greenLedMinutes: Int,
        val blueLedMinutes: Int
    )

    data class ScheduleAction(
        val device: String,
        val state: String,
        val temperature: Int? = null,
        val speed: Int? = null,
        val mode: String? = null
    )

    // Connect to MQTT Broker
    fun connect(deviceId: String = "esp32_home_001") {
        currentDeviceId = deviceId

        try {
            val clientId = "AndroidApp_" + System.currentTimeMillis()
            Log.d(tag, "Connecting to $brokerUrl with ID: $clientId")

            mqttClient = MqttAndroidClient(context, brokerUrl, clientId)

            mqttClient?.setCallback(object : MqttCallback {
                override fun connectionLost(cause: Throwable?) {
                    Log.e(tag, "Connection lost: ${cause?.message}")
                    onConnectionStatusChanged?.invoke(false, "Disconnected")
                }

                override fun messageArrived(topic: String?, message: MqttMessage?) {
                    if (message != null) {
                        val payload = String(message.payload)
                        Log.d(tag, "Message received: $payload")
                        handleIncomingMessage(payload)
                    }
                }

                override fun deliveryComplete(token: IMqttDeliveryToken?) {
                    Log.d(tag, "Message delivered")
                }
            })

            val options = MqttConnectOptions()
            options.isCleanSession = true
            options.connectionTimeout = 30
            options.keepAliveInterval = 60
            options.isAutomaticReconnect = true

            mqttClient?.connect(options, null, object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken?) {
                    Log.d(tag, "Connected successfully!")
                    onConnectionStatusChanged?.invoke(true, "Connected")
                    subscribeToTopics()
                }

                override fun onFailure(asyncActionToken: IMqttToken?, exception: Throwable?) {
                    Log.e(tag, "Connection failed: ${exception?.message}")
                    onConnectionStatusChanged?.invoke(false, "Connection Failed")
                }
            })

        } catch (e: Exception) {
            Log.e(tag, "Connection error: ${e.message}")
            onConnectionStatusChanged?.invoke(false, "Error")
        }
    }

    // Subscribe to telemetry topic
    private fun subscribeToTopics() {
        try {
            Log.d(tag, "Subscribing to: $telemetryTopic")

            mqttClient?.subscribe(telemetryTopic, 0, null, object : IMqttActionListener {
                override fun onSuccess(asyncActionToken: IMqttToken?) {
                    Log.d(tag, "Subscribed successfully to $telemetryTopic")
                }

                override fun onFailure(asyncActionToken: IMqttToken?, exception: Throwable?) {
                    Log.e(tag, "Subscription failed: ${exception?.message}")
                }
            })
        } catch (e: Exception) {
            Log.e(tag, "Subscribe error: ${e.message}")
        }
    }

    // Parse incoming telemetry messages
    private fun handleIncomingMessage(payload: String) {
        try {
            val json = JSONObject(payload)

            // Skip online status messages
            if (json.has("status") && json.optString("status") == "online") {
                Log.d(tag, "Skipping online status message")
                return
            }

            val temperature = json.optDouble("temperature", 0.0)
            val humidity = json.optDouble("humidity", 0.0)
            val redLed = json.optInt("red_led", 0)
            val greenLed = json.optInt("green_led", 0)
            val acPower = json.optBoolean("ac_power", false)
            val acTargetTemp = json.optInt("ac_target_temp", 24)
            val fanPower = json.optBoolean("fan_power", false)
            val fanSpeed = json.optInt("fan_speed", 2)

            Log.d(tag, "Parsed - Temp: $temperature, Humidity: $humidity")

            val energyJson = json.optJSONObject("energy")
            val energyData = if (energyJson != null) {
                EnergyData(
                    acMinutes = energyJson.optInt("ac_minutes", 0),
                    fanMinutes = energyJson.optInt("fan_minutes", 0),
                    redLedMinutes = energyJson.optInt("red_led_minutes", 0),
                    greenLedMinutes = energyJson.optInt("green_led_minutes", 0),
                    blueLedMinutes = energyJson.optInt("blue_led_minutes", 0)
                )
            } else {
                EnergyData(0, 0, 0, 0, 0)
            }

            val telemetryData = TelemetryData(
                temperature, humidity, redLed, greenLed,
                acPower, acTargetTemp, fanPower, fanSpeed, energyData
            )

            onTelemetryReceived?.invoke(telemetryData)

        } catch (e: Exception) {
            Log.e(tag, "JSON parsing error: ${e.message}")
        }
    }

    // Control LED (with inversion for active-low hardware)
    fun controlLed(ledName: String, state: String) {
        if (mqttClient?.isConnected != true) {
            Log.e(tag, "Not connected - cannot control LED")
            return
        }

        // INVERT state for active-low LEDs
        val invertedState = if (state == "ON") "OFF" else "ON"

        val command = JSONObject()
        command.put("led", ledName)
        command.put("state", invertedState)

        Log.d(tag, "LED Control: $ledName -> $state (sending $invertedState)")
        publishCommand(command)
    }

    // Control AC
    fun controlAC(power: String, temperature: Int, mode: String) {
        if (mqttClient?.isConnected != true) {
            Log.e(tag, "Not connected - cannot control AC")
            return
        }

        val command = JSONObject()
        command.put("device", "ac")
        command.put("state", power)
        command.put("temperature", temperature)
        command.put("mode", mode)

        Log.d(tag, "AC Control: $power, Temp: $temperature")
        publishCommand(command)
    }

    // Control Fan
    fun controlFan(power: String, speed: Int) {
        if (mqttClient?.isConnected != true) {
            Log.e(tag, "Not connected - cannot control Fan")
            return
        }

        val command = JSONObject()
        command.put("device", "fan")
        command.put("state", power)
        command.put("speed", speed)

        Log.d(tag, "Fan Control: $power, Speed: $speed")
        publishCommand(command)
    }

    // Execute schedule (Sleep Mode, Away Mode)
    fun executeSchedule(scheduleName: String, actions: List<ScheduleAction>) {
        if (mqttClient?.isConnected != true) {
            Log.e(tag, "Not connected - cannot execute schedule")
            return
        }

        val actionsArray = JSONArray()
        for (action in actions) {
            val actionJson = JSONObject()
            actionJson.put("device", action.device)

            // Invert LED states in schedules
            if (action.device == "all_leds" || action.device.contains("led")) {
                val invertedState = if (action.state == "ON") "OFF" else "ON"
                actionJson.put("state", invertedState)
            } else {
                actionJson.put("state", action.state)
            }

            action.temperature?.let { actionJson.put("temperature", it) }
            action.speed?.let { actionJson.put("speed", it) }
            action.mode?.let { actionJson.put("mode", it) }
            actionsArray.put(actionJson)
        }

        val command = JSONObject()
        command.put("device", "schedule")
        command.put("name", scheduleName)
        command.put("actions", actionsArray)

        Log.d(tag, "Schedule: $scheduleName")
        publishCommand(command)
    }

    // Publish command to MQTT broker
    private fun publishCommand(command: JSONObject) {
        try {
            val message = MqttMessage()
            message.payload = command.toString().toByteArray()
            message.qos = 0
            mqttClient?.publish(controlTopic, message)
            Log.d(tag, "Command sent: $command")
        } catch (e: Exception) {
            Log.e(tag, "Publish error: ${e.message}")
        }
    }

    // Disconnect from broker
    fun disconnect() {
        try {
            mqttClient?.disconnect()
            Log.d(tag, "Disconnected from broker")
            onConnectionStatusChanged?.invoke(false, "Disconnected")
        } catch (e: Exception) {
            Log.e(tag, "Disconnect error: ${e.message}")
        }
    }

    // Check connection status
    fun isConnected(): Boolean {
        return mqttClient?.isConnected ?: false
    }
}