package com.example.iot_ui

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.snackbar.Snackbar
import com.example.iot_ui.databinding.ActivityMainBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var mqttManager: MqttManager? = null
    private val tag = "MainActivity"

    // UI States
    private var redLedState = false
    private var greenLedState = false
    private var acState = false
    private var acTargetTemp = 24
    private var fanState = false
    private var fanSpeed = 2

    // Device configuration
    private val devices = arrayOf("esp32_home_001")
    private var selectedDevice = "esp32_home_001"
    private var isReady = false

    // Energy cost per kWh
    private val costPerKwh = 0.12

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupDeviceSpinner()
        setupButtons()

        // Initialize MQTT after short delay
        lifecycleScope.launch {
            delay(500)
            setupMqtt()
            isReady = true
        }
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener {
            showSnackbar("ESP32 Smart Home Controller - Capstone Project")
        }
    }

    private fun setupDeviceSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, devices)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.deviceSpinner.adapter = adapter

        binding.deviceSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val newDevice = devices[position]
                if (newDevice != selectedDevice && isReady) {
                    selectedDevice = newDevice
                    reconnectToDevice()
                } else {
                    selectedDevice = newDevice
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun setupMqtt() {
        mqttManager = MqttManager(applicationContext)

        // Connection status callback
        mqttManager?.onConnectionStatusChanged = { isConnected, status ->
            runOnUiThread {
                Log.d(tag, "Connection status changed: $isConnected - $status")
                updateConnectionStatus(isConnected, status)
                if (isConnected) {
                    showSnackbar("Connected to ESP32!")
                }
            }
        }

        // Telemetry data callback
        mqttManager?.onTelemetryReceived = { data ->
            runOnUiThread {
                Log.d(tag, "Telemetry received - Temp: ${data.temperature}, Hum: ${data.humidity}")

                // Update temperature and humidity display
                binding.tvTemperature.text = String.format("%.1f", data.temperature)
                binding.tvHumidity.text = String.format("%.1f", data.humidity)

                // Update AC state
                acState = data.acPower
                acTargetTemp = data.acTargetTemp
                binding.switchAc.isChecked = data.acPower
                binding.tvAcTemp.text = "${data.acTargetTemp}°C"

                // Update Fan state
                fanState = data.fanPower
                fanSpeed = data.fanSpeed
                binding.switchFan.isChecked = data.fanPower
                when (data.fanSpeed) {
                    1 -> binding.chipSpeedLow.isChecked = true
                    2 -> binding.chipSpeedMedium.isChecked = true
                    3 -> binding.chipSpeedHigh.isChecked = true
                }

                // Update energy data
                updateEnergyDisplay(data.energyData)
            }
        }

        // Connect to broker
        mqttManager?.connect(selectedDevice)
    }

    private fun setupButtons() {
        // Red LED Button
        binding.btnRedLed.setOnClickListener {
            if (!isReady || mqttManager?.isConnected() != true) {
                showSnackbar("Not connected to ESP32")
                return@setOnClickListener
            }

            redLedState = !redLedState
            val state = if (redLedState) "ON" else "OFF"
            mqttManager?.controlLed("red", state)
            updateRedButton()
            showSnackbar("Red LED → $state")
        }

        // Green LED Button
        binding.btnGreenLed.setOnClickListener {
            if (!isReady || mqttManager?.isConnected() != true) {
                showSnackbar("Not connected to ESP32")
                return@setOnClickListener
            }

            greenLedState = !greenLedState
            val state = if (greenLedState) "ON" else "OFF"
            mqttManager?.controlLed("green", state)
            updateGreenButton()
            showSnackbar("Green LED → $state")
        }

        // AC Switch
        binding.switchAc.setOnCheckedChangeListener { _, isChecked ->
            if (!isReady || mqttManager?.isConnected() != true) {
                return@setOnCheckedChangeListener
            }

            acState = isChecked
            val state = if (isChecked) "ON" else "OFF"
            mqttManager?.controlAC(state, acTargetTemp, "cool")
            showSnackbar("AC → $state")
        }

        // Temperature Minus Button
        binding.btnTempMinus.setOnClickListener {
            if (acTargetTemp > 16) {
                acTargetTemp--
                binding.tvAcTemp.text = "${acTargetTemp}°C"
                if (acState && isReady && mqttManager?.isConnected() == true) {
                    mqttManager?.controlAC("ON", acTargetTemp, "cool")
                }
            }
        }

        // Temperature Plus Button
        binding.btnTempPlus.setOnClickListener {
            if (acTargetTemp < 30) {
                acTargetTemp++
                binding.tvAcTemp.text = "${acTargetTemp}°C"
                if (acState && isReady && mqttManager?.isConnected() == true) {
                    mqttManager?.controlAC("ON", acTargetTemp, "cool")
                }
            }
        }

        // Fan Switch
        binding.switchFan.setOnCheckedChangeListener { _, isChecked ->
            if (!isReady || mqttManager?.isConnected() != true) {
                return@setOnCheckedChangeListener
            }

            fanState = isChecked
            val state = if (isChecked) "ON" else "OFF"
            mqttManager?.controlFan(state, fanSpeed)
            showSnackbar("Fan → $state")
        }

        // Fan Speed Chips
        binding.chipGroupFanSpeed.setOnCheckedChangeListener { _, checkedId ->
            fanSpeed = when (checkedId) {
                R.id.chipSpeedLow -> 1
                R.id.chipSpeedMedium -> 2
                R.id.chipSpeedHigh -> 3
                else -> 2
            }
            if (fanState && isReady && mqttManager?.isConnected() == true) {
                mqttManager?.controlFan("ON", fanSpeed)
            }
        }

        // Sleep Mode Button
        binding.btnSleepMode.setOnClickListener {
            if (!isReady || mqttManager?.isConnected() != true) {
                showSnackbar("Not connected to ESP32")
                return@setOnClickListener
            }

            showSnackbar("Activating Sleep Mode...")
            val actions = listOf(
                MqttManager.ScheduleAction("all_leds", "OFF"),
                MqttManager.ScheduleAction("ac", "ON", temperature = 26, mode = "cool"),
                MqttManager.ScheduleAction("fan", "ON", speed = 1)
            )
            mqttManager?.executeSchedule("Sleep Mode", actions)
        }

        // Away Mode Button
        binding.btnAwayMode.setOnClickListener {
            if (!isReady || mqttManager?.isConnected() != true) {
                showSnackbar("Not connected to ESP32")
                return@setOnClickListener
            }

            showSnackbar("Activating Away Mode...")
            val actions = listOf(
                MqttManager.ScheduleAction("all_leds", "OFF"),
                MqttManager.ScheduleAction("ac", "OFF"),
                MqttManager.ScheduleAction("fan", "OFF")
            )
            mqttManager?.executeSchedule("Away Mode", actions)
        }

        // Refresh Button
        binding.fabRefresh.setOnClickListener {
            if (!isReady) {
                showSnackbar("Please wait, initializing...")
                return@setOnClickListener
            }

            showSnackbar("Reconnecting to ESP32...")
            lifecycleScope.launch {
                mqttManager?.disconnect()
                delay(1000)
                mqttManager?.connect(selectedDevice)
            }
        }
    }

    private fun reconnectToDevice() {
        if (!isReady) return

        showSnackbar("Switching to $selectedDevice...")

        lifecycleScope.launch {
            mqttManager?.disconnect()
            delay(1000)

            // Reset states
            redLedState = false
            greenLedState = false
            acState = false
            fanState = false
            acTargetTemp = 24
            fanSpeed = 2

            runOnUiThread {
                updateRedButton()
                updateGreenButton()
                binding.switchAc.isChecked = false
                binding.switchFan.isChecked = false
                binding.tvAcTemp.text = "24°C"
                binding.chipSpeedMedium.isChecked = true
                binding.tvTemperature.text = "0.0"
                binding.tvHumidity.text = "0.0"
            }

            mqttManager?.connect(selectedDevice)
        }
    }

    private fun updateConnectionStatus(isConnected: Boolean, status: String) {
        binding.tvStatus.text = status
        binding.tvStatus.setTextColor(
            if (isConnected) Color.parseColor("#4CAF50")
            else Color.parseColor("#F44336")
        )
    }

    private fun updateEnergyDisplay(energyData: MqttManager.EnergyData) {
        // Update runtime displays
        binding.tvAcRuntime.text = "${energyData.acMinutes} min"
        binding.tvFanRuntime.text = "${energyData.fanMinutes} min"

        val totalLedMinutes = energyData.redLedMinutes +
                energyData.greenLedMinutes +
                energyData.blueLedMinutes
        binding.tvLedRuntime.text = "$totalLedMinutes min"

        // Calculate energy cost
        val acCost = (energyData.acMinutes / 60.0) * 1.5 * costPerKwh
        val fanCost = (energyData.fanMinutes / 60.0) * 0.075 * costPerKwh
        val ledCost = (totalLedMinutes / 60.0) * 0.02 * costPerKwh
        val totalCost = acCost + fanCost + ledCost

        binding.tvEnergyCost.text = String.format("$%.2f", totalCost)
    }

    private fun updateRedButton() {
        binding.btnRedLed.text = if (redLedState) "SWITCH OFF" else "SWITCH ON"
        binding.btnRedLed.backgroundTintList = getColorStateList(
            if (redLedState) android.R.color.darker_gray else R.color.cyan_primary
        )
    }

    private fun updateGreenButton() {
        binding.btnGreenLed.text = if (greenLedState) "SWITCH OFF" else "SWITCH ON"
        binding.btnGreenLed.backgroundTintList = getColorStateList(
            if (greenLedState) android.R.color.darker_gray else R.color.red_orange
        )
    }

    private fun showSnackbar(message: String) {
        Snackbar.make(binding.root, message, Snackbar.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        mqttManager?.disconnect()
    }

    override fun onResume() {
        super.onResume()
        if (isReady && mqttManager?.isConnected() == false) {
            lifecycleScope.launch {
                mqttManager?.connect(selectedDevice)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        // Keep connection alive in background
    }
}